# Faceless Shorts SaaS — Starter

## Codespaces Quickstart
1) Open in Codespaces → Terminal:
```
npm install
cp .env.example .env.local
npm run dev
```
Open forwarded port 3000.

## Next steps
- Fill API stubs in `src/pages/api/*`
- Deploy to Vercel/Render and set env vars
