import Link from 'next/link';
export default function Home() {
  return (<main style={{minHeight:'100vh',display:'flex',alignItems:'center',justifyContent:'center',fontFamily:'system-ui'}}>
    <div style={{maxWidth:720,padding:24}}>
      <h1 style={{fontSize:36,marginBottom:12}}>Faceless Shorts — AI Video Machine</h1>
      <p style={{opacity:0.8,marginBottom:24}}>Generate vertical shorts with AI and auto-post.</p>
      <div style={{display:'flex',gap:12}}>
        <Link href="/dashboard" style={{padding:'10px 16px',background:'#111',color:'#fff',borderRadius:8,textDecoration:'none'}}>Go to Dashboard</Link>
      </div>
    </div></main>);
}