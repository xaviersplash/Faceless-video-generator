import type { NextApiRequest, NextApiResponse } from 'next'; import Stripe from 'stripe';
export const config = { api: { bodyParser: false } };
function buffer(readable:any){return new Promise<Buffer>((resolve,reject)=>{const chunks:any[]=[];readable.on('data',(c:any)=>chunks.push(Buffer.from(c)));readable.on('end',()=>resolve(Buffer.concat(chunks)));readable.on('error',reject);});}
export default async function handler(req: NextApiRequest, res: NextApiResponse){
  const stripe = new Stripe(process.env.STRIPE_SECRET_KEY||'', { apiVersion: '2024-06-20' as any });
  const sig = req.headers['stripe-signature'] as string|undefined; if(!sig) return res.status(400).send('Missing signature');
  try{ const buf = await buffer(req); const event = stripe.webhooks.constructEvent(buf, sig, process.env.STRIPE_WEBHOOK_SECRET||''); console.log('Stripe event:', event.type); return res.status(200).json({received:true}); }
  catch(err:any){ console.error(err); return res.status(400).send(`Webhook Error: ${err.message}`); }
}