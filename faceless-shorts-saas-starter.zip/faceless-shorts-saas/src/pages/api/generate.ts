import type { NextApiRequest, NextApiResponse } from 'next';
import path from 'node:path'; import fs from 'node:fs';
import ffmpeg from 'fluent-ffmpeg'; import ffmpegStatic from 'ffmpeg-static';
ffmpeg.setFfmpegPath(ffmpegStatic as string);
export default async function handler(req: NextApiRequest, res: NextApiResponse){
  try{ if(req.method!=='POST') return res.status(405).json({error:'Method not allowed'});
    const {topic='fun facts'} = req.body||{};
    const outDir = path.join(process.cwd(),'public','generated'); fs.mkdirSync(outDir,{recursive:true});
    const outPath = path.join(outDir,`short-${Date.now()}.mp4`);
    await new Promise<void>((resolve,reject)=>{ ffmpeg().input('color=c=black:s=720x1280:r=30').inputFormat('lavfi').videoCodec('libx264').duration(5).outputOptions('-pix_fmt yuv420p','-movflags +faststart').save(outPath).on('end',()=>resolve()).on('error',(e)=>reject(e)); });
    const publicUrl = `/generated/${path.basename(outPath)}`;
    return res.status(200).json({ok:true,topic,videoUrl:publicUrl});
  }catch(e:any){ console.error(e); return res.status(500).json({error:e.message||'Unknown error'}); }
}