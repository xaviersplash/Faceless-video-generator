export function getYouTubeClientForUser(userId: string){ return null; }
