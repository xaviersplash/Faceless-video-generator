export const PLANS = { STARTER:{priceId:'price_starter',credits:30}, POPULAR:{priceId:'price_popular',credits:60}, PRO:{priceId:'price_pro',credits:500} } as const;
